export const Pi =3.1415;

export function factorial(n){
    let f =1;
    for (let i = 0;i<=n;i++)
        f*=i;
    return f;
}