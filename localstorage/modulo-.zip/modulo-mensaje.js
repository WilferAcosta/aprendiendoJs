const mensaje= ()=>{
    const nombre = "wilfer";
    const edad = 28;
    return nombre + "tiene " +edad+ " años.";
};
export {mensaje};