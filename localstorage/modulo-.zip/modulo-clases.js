export function suma(a,b){
    return a + b;
}
export function resta(a,b){
    return a-b;
}

export const PI = 3.1416;
export const spuntnik = {
    nivel : ' intermedio',
    capacidad: '35',
    canoers: 30,
    promedi: 25
};
export class Camper {
    static mensaje(){
        return 'listo para el test del lunes'
    };
}
const name = " wilfer de class";
