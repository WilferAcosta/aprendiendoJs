function calcular(){
    let cedula=document.getElementById("cedula").value;
    let nombre=document.getElementById("nombre").value;
    let categoria=document.getElementById("categoria").value;
    let cate=categoria.toLowerCase();
    let salarioBruto=0;
    let bonificacion=0;
    let auxilio=0;
    let eps=0;
    let pension=0;
    switch (cate){
        case "auxiliara":
            salarioBruto+= 1160000;
            bonificacion+=100000;
            break;

        case "auxiliarb":
            salarioBruto+= 1200000;
            bonificacion+=100000;
            break;

        case "tecnicoa":
            salarioBruto+=1500000;
            bonificacion+=150000;
            break;

        case "tecnicob":
            salarioBruto+=2000000;
            bonificacion+=15000;
            break;

        case "profecionala":
            salarioBruto+=2500000;
            bonificacion+=200000;
            break;

        case "profecionalb":
            salarioBruto+=3000000;
            bonificacion+=250000;
            break;

        case "directora":
            salarioBruto+=4000000;
            bonificacion+=500000;
            break;

        case "directorb":
            salarioBruto+=4500000;
            bonificacion+=1000000;
            break;

        case "gerentedepartamento":
            salarioBruto+=6000000;
            bonificacion+=2000000;
            break;

        case "gerentegeneral":
            salarioBruto+=5000000;
            bonificacion+=5000000;
            break;
        default:
            alert("categoria no existe Intenta de nuevo")

    }
    if (salarioBruto<1500000){
        salarioBruto+=salarioBruto
        auxilio=400000;
        eps=salarioBruto*0.04;
        pension=salarioBruto*0.04;
        salarioTotal=salarioBruto+auxilio+bonificacion-eps-pension
    }else{
        salarioBruto;
        eps=salarioBruto*0.04;
        pension=salarioBruto*0.04;
        salarioTotal=salarioBruto+bonificacion-eps-pension
        auxilio=0;
    }
    
    const usuario = new Array;
    usuario.push(cedula,nombre,categoria,salarioBruto,auxilio,bonificacion,eps,pension,salarioTotal);
    datos.push(usuario);
    cont += `<tr><td>${usuario[0]}</td><td>${usuario[1]}</td><td>${usuario[2]}</td><td>${usuario[3]}</td><td>${usuario[4]}</td><td>${usuario[5]}</td><td>${usuario[6]}</td><td>${usuario[7]}</td><td>${usuario[8]}</td></tr>`;
    document.getElementById("tabla").innerHTML= cont; 
    console.log(datos);
    let totalSalarios=0;
    for(let i=0;i<=datos.length;i++){
    
        for(j=0;j<=datos[i].length;j++){
            totalSalarios+=datos[i][8];
            console.log(totalSalarios);
        }
    }
    console.log(totalSalarios);
    
}
const datos = new Array;
let cont ="";
console.log(datos);
